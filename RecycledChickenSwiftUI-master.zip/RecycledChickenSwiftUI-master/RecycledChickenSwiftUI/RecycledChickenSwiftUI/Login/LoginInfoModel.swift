//
//  LoginInfoModel.swift
//  RecycledChickenSwiftUI
//
//  Created by 林書郁 on 2024/1/9.
//

import Foundation

struct AccountInfo: Codable {
    var userPhoneNumber:String
    var userPassword:String
}

