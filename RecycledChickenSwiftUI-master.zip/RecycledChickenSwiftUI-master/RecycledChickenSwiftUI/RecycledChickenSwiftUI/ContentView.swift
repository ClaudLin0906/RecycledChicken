//
//  ContentView.swift
//  RecycledChickenSwiftUI
//
//  Created by 林書郁 on 2024/1/2.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        Text("123 ")
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
} 
