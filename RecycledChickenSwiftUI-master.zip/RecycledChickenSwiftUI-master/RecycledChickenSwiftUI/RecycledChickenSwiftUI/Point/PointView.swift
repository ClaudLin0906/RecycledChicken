//
//  PointView.swift
//  RecycledChickenSwiftUI
//
//  Created by 林書郁 on 2024/1/11.
//

import SwiftUI

struct PointView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct PointView_Previews: PreviewProvider {
    static var previews: some View {
        PointView()
    }
}
